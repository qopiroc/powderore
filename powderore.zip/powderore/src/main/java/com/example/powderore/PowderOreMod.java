package com.example.powderore;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(PowderOreMod.MOD_ID)
public class PowderOreMod {
    public static final String MOD_ID = "powderore";

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);

    // ---- Блоки (руды) ----
    public static final DeferredBlock<Block> SULFUR_ORE = BLOCKS.registerSimpleBlock(
            "sulfur_ore", BlockBehaviour.Properties.ofFullCopy(Blocks.COAL_ORE));
    public static final DeferredBlock<Block> SALTPETER_ORE = BLOCKS.registerSimpleBlock(
            "saltpeter_ore", BlockBehaviour.Properties.ofFullCopy(Blocks.COAL_ORE));

    // ---- Предметы ----
    public static final DeferredItem<BlockItem> SULFUR_ORE_ITEM =
            ITEMS.registerSimpleBlockItem("sulfur_ore", SULFUR_ORE);
    public static final DeferredItem<BlockItem> SALTPETER_ORE_ITEM =
            ITEMS.registerSimpleBlockItem("saltpeter_ore", SALTPETER_ORE);

    public static final DeferredItem<Item> SULFUR =
            ITEMS.registerSimpleItem("sulfur", new Item.Properties());
    public static final DeferredItem<Item> SALTPETER =
            ITEMS.registerSimpleItem("saltpeter", new Item.Properties());

    public PowderOreMod(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        modEventBus.addListener(this::addCreative);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
            event.accept(SULFUR_ORE_ITEM);
            event.accept(SALTPETER_ORE_ITEM);
        }
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(SULFUR);
            event.accept(SALTPETER);
        }
    }
}
